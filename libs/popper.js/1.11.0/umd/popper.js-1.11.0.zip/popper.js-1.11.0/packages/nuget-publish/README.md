# nuget-publish

Publish a Nuget package using your package.json to automatically generate a nuspec file.
